
--actionVerb
table.insert(functionslist,"penis")

function penisName()

	return penisNames[math.random(1,#penisNames)]
	
end