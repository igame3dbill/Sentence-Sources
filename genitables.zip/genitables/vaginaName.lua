
--actionVerb
table.insert(functionslist,"vagina")

function vaginaName()

	return vaginaNames[math.random(1,#vaginaNames)]
	
end